import playsound

playsound.playsound("menu.mp3")
